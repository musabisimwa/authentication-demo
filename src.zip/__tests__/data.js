exports.sampleSignUp = {
      "userName":"user.name2",
      "password":"FiveBoys23#",
      "email":"user@email.com"
    }



modules.exports =exports;