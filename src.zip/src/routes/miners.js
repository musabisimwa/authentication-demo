const {
  updateMiner,
  getAMiner,
  getAllMiners,
  deleteMiner,
  addMiner,
} = require("../services/minerService");
const { newMinerFromUpdates } = require("../utils/minerUtils");
const { minerValidator } = require("../utils/validators");

/**
 *  GET /
 * @param {*} req
 * @param {*} res
 */
const getAll = (req, res) => {
  getAllMiners()
    .then((miners) => {
      if (Array.isArray(miners)) {
        return res.status(200).json(miners);
      }
      // return an empty array if no miners
      return res.status(200).json([]);
    })
    .catch((error) => {
      console.error(error);
      return res.status(500).json({ msg: "internal server error" });
    });
};

/**
 *  GET /:id
 * @param {*} req
 * @param {*} res
 */
const getOne = (req, res) => {
  const id = req.params.id;

  if (typeof id === "number") {
    getAMiner(id)
      .then((miner) => {
        //if miner exists
        if (miner) {
          return res.status(200).json(miner);
        }
        return res.status(404).json({ msg: "not found" });
      })
      .catch((error) => {
        console.error(error);
        return res.status(500).json({ msg: "Internal server error" });
      });
  }
  return res.status(404).json({ msg: "not found" });
};

/**
 * PUT /:id
 * @param {*} req
 * @param {*} res
 */
const update = (req, res) => {
  const user = req.user;
  const paramId = req.params.id;

  //if any precondition is missing or undefined return 401
  if (!(user && paramId)) {
    return res.status(401).json({ msg: "unathorized" });
  }
  const updatedMiner = req.body;
  // if not valid : 400
  if (!updatedMiner) {
    return res.status(400).json({ msg: "bad request : empty body" });
  }

  const existingMiner = getAMiner(paramId);
  const newMiner = newMinerFromUpdates(existingMiner, updatedMiner);

  if (newMiner) {
    //update miner belonging to user:user
    updateMiner(paramId, user, newMiner)
      .then((miner) => {
        // if a miner is return and that this user owns it
        if (miner) {
          return res.status(200).json(miner);
        }
        //will return 401 after promise is done
      })
      .catch((error) => {
        //caught errors
        console.error(error);
        return res.status(500).json({ msg: "Internal server error" });
      });
  }
  // miner not valid from newMinerFromUpdates
  //or the current user doesnt own it
  return res.status(401).json({ msg: "unathorized" });
};
const deleteAMiner = (req, res) => {
  const user = req.user;
  const paramId = req.params.id;

  if (!(user && paramId)) {
    return res.status(401).json({ msg: "unathorized" });
  }
  //delete miner service
  deleteMiner()
    .then((action) => {
      if (action) {
        return res.status(200).json({});
      }
    })
    .catch((error) => {
      //failed to delete
      console.error(error);
      return res.status(500).json({ msg: "Internal server error" });
    });
};

const post=(req,res)=>{

    const miner = req.body;
    const user = req.user;

    if (!(user && miner)) {
        return res.status(401).json({ msg: "unathorized" });
      }

      
    //validate miner
    if(!minerValidator(miner)){
        //not valid body
    return res.status(400).json({ msg: "bad request " });

    }

    addMiner(miner,user).then(id=>{
        if(id){
            return res.status(201).json({id:id});
        }
    }).catch(err=>{
        console.error(err);
      return res.status(500).json({ msg: "Internal server error" });

    });
    // if not created 
    return res.status(401).json({ msg: "unathorized" });


}

module.exports = { getAll, update, getOne, deleteAMiner ,post};
