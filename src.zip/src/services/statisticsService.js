// statisical functions here

// get active miners 

//calculate the hashes

// get the mockDifficulties from test/data :create an obj 
//return {hashrateArray,difficulties}
